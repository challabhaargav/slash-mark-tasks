# SlashMark-Basic-Tasks
Task-1: Simple To Do List

Task-2: Number Guess Game

Task-3: Password Generator

